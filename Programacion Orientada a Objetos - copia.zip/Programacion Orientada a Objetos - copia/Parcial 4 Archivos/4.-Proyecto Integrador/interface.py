class DatosInterface():

    def obtenerListaArchivo(self):
        pass

    def media(self):
        pass

    def moda(self):
        pass

    def mediana(self):
        pass

class DiagramaInterface():

    def obtenerListaArchivo(self):
        pass

    def ordenar(self,conj):
        pass

    def obtenerTallos(self,c):
        pass

    def resolverDiagrama(self,t,conj):
        pass

    def mostrarDiagrama(self):
        pass


    
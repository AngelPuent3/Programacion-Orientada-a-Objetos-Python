class ConjuntoFichero:
    def __init__(self, nombreFichero):
      
    #junto los ficheros de los modulos en uno solo
   
 
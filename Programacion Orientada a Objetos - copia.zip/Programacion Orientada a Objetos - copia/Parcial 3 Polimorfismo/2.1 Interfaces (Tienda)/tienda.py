class Electro:
    def imprimirInfo(self):
        pass
    def capturarInfo(self):
        pass
    def menu(self):
        pass

class Tienda:
    def __init__(self):
        self.codigo=0
        self.nombre=""
        self.tamaño=""
        self.precio=0
        self.costo=0

      



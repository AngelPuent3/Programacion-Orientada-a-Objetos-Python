class Persona:
    def __init__(self):
        self.nombre = str
        self.RFC = str
        self.tipoPaga = int
        self.paga = int

    def calcularSalario(self):
        pass
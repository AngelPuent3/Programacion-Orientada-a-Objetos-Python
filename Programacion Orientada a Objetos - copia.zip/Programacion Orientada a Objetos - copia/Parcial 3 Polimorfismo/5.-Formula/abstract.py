from abc import ABC, abstractmethod

class Variables(ABC):
    def __init__(self):
        self.a = int
        self.b = int
        self.c = int
